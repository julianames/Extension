let startTime = Date.now();

// When the page unloads, send the time spent to the background script
function sendTimeSpent() {
  const timeSpent = Date.now() - startTime;
  chrome.runtime.sendMessage({timeSpent: timeSpent, url: window.location.href});
  console.log("Time spent on site:", timeSpent);
}

// Set up a timer to trigger every 2 minutes
setInterval(sendTimeSpent, 120000 / 8);