document.addEventListener('DOMContentLoaded', function () {
  loadToDoItems();

  document.getElementById('addBtn').addEventListener('click', addToDo);
  document.getElementById('toDoInput').addEventListener('keypress', function (event) {
    if (event.key === 'Enter') {
      event.preventDefault();
      addToDo();
    }
  });

  // Attach event listeners dynamically for all existing and future delete buttons
  document.querySelectorAll('.delete-btn').forEach(function (button) {
    button.addEventListener('click', function () {
      // Ensure `button` is the clicked button within the handler
      const listItem = this.parentNode; // Use 'this' for the clicked button
      const itemText = listItem.querySelector('span').textContent; // Get the text content

      listItem.remove(); // Remove the list item
      updateStoredList(itemText, false); // Mark the item as deleted in storage
    });
  });
});

function addToDo() {
  const input = document.getElementById('toDoInput');
  const newItem = input.value.trim();
  if (!newItem) {
    alert('Please enter a to-do item.');
    return;
  }

  storeToDoItems(newItem);

  input.value = ''; // Clear the input field
}

function addItemToList(itemText, isChecked) {
  const list = document.getElementById(isChecked ? 'toDoListDone' : 'toDoListNotDone');
  const listItem = document.createElement('li');

  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.checked = isChecked;
  checkbox.addEventListener('change', function () {
    updateStoredList(itemText, this.checked);
    listItem.remove();
    addItemToList(itemText, this.checked);
    if (!isChecked) {
      chrome.storage.sync.set({'poop': false}, function() {
        console.log('"poop" has been set to false.')
      })
    }
  });

  const deleteBtn = document.createElement('button');
  deleteBtn.classList.add('delete-btn'); // Use class for styling
  deleteBtn.textContent = 'Delete';

  // Ensure the event listener is attached within the function:
  deleteBtn.addEventListener('click', function () {
    const listItem = this.parentNode; // Use 'this' for the clicked button
    const itemText = listItem.querySelector('span').textContent; // Get the text content
    listItem.remove(); // Remove the list item from the UI
    updateStoredList(itemText, false, true); // Mark the item as deleted in storage
  });

  const span = document.createElement('span');
  span.textContent = itemText;

  listItem.appendChild(checkbox);
  listItem.appendChild(span);
  listItem.appendChild(deleteBtn);
  list.appendChild(listItem);
}

function storeToDoItems(newItem) {
  chrome.storage.sync.get({ todoItems: [] }, function (data) {
    data.todoItems.push({ text: newItem, checked: false });
    chrome.storage.sync.set({ todoItems: data.todoItems }, function () {
      addItemToList(newItem, false); // Add the item to the list after storing
    });
  });
}

function loadToDoItems() {
  chrome.storage.sync.get({ todoItems: [] }, function (data) {
    data.todoItems.forEach(function (item) {
      addItemToList(item.text, item.checked);
    });
  });
}

function updateStoredList(itemText, isChecked, isDeleted = false) {
    chrome.storage.sync.get({ todoItems: [] }, function (data) {
      const index = data.todoItems.findIndex(item => item.text === itemText);
      if (index !== -1) {
        if (isDeleted) {
          // Remove the item from the array if marked for deletion
          data.todoItems.splice(index, 1);
        } else {
          // Update the checked status as before
          data.todoItems[index].checked = isChecked;
        }
        // Save the updated array back to storage
        chrome.storage.sync.set({ todoItems: data.todoItems });
      }
    });
  }
