Ok, so we now can navigate between HTML pages for each of our tabs. Here are a few things we need to figure out to further develop the extension:
If we're able to figure out these small pieces, we can integrate them within in the extension fairly easily. baby steps
1: Tracking the amount of time a user spends on a site
    We can simplify the scope by removing the site blocker feature and instead having the dog grow happier or sadder depending on what
    the user is on.
