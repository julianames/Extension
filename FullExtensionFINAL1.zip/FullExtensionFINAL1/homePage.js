chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    if (message.action === "updateState") {
      updateStateDisplay(message.state);
      updatePintoImage(message.state);
    }
  });
  
  function updateStateDisplay(newState) {
    const stateElement = document.getElementById('stateValue'); // Ensure your HTML has this ID
    if (stateElement) {
      if (newState == 'sad') {
        stateElement.textContent = "Pinto is sad! Cheer him up by spending more time on your productive websites."
      } else if (newState == 'poop') {
        stateElement.textContent = "Pinto needs to use the bathroom! Help him relieve his bowels by checking an item off your to-do list."
      } else if (newState == 'happy') {
        stateElement.textContent = "You're a great pet owner - Pinto is super happy!"
      } else if (newState == 'content') {
        stateElement.textContent = "Pinto is big chillin right now."
      }
    }
  }

  function updatePintoImage(newState) {
    // Retrieve the current image ID from chrome.storage.sync
    chrome.storage.sync.get(['currentImageID'], function(result) {
      let currentImageID = result.currentImageID || 'defaultPinto';
      let newImageSrc = determineNewImageSrc(newState, currentImageID);
      console.log(newImageSrc + 'state: ' + newState);
  
      // Update the image element's source
      const imageElement = document.getElementById('pintoImage');
      if (imageElement) {
        imageElement.src = newImageSrc;
      }
      });
  }
  
  function determineNewImageSrc(newState, currentImageID) {
    if (currentImageID =='blueCollar') {
      if (newState == 'poop') {
        return 'pinto images/pintoCollarPoop.png'
      } else if (newState == 'sad') {
        return 'pinto images/pintoCollarSad.png'
      } else if (newState == 'happy') {
        return 'pinto images/pintoHappyCollar.png'
      } else {
        return 'pinto images/pintoCollar.png'
      }
    } else if (currentImageID =='defaultPinto') {
      if (newState == 'poop') {
        return 'pinto images/pintoPoop.png'
      } else if (newState == 'sad') {
        return 'pinto images/pinto sad.png'
      } else if (newState == 'happy') {
        return 'pinto images/pintoHappy.png'
      } else {
        return 'pinto images/pinto.png'
      }

    }
  }
  
  document.addEventListener('DOMContentLoaded', () => {
    chrome.storage.sync.get(['state'], function(result) {
      updateStateDisplay(result.state || 'Unknown');
    });
  });