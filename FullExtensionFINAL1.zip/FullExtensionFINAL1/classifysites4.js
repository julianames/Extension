document.addEventListener('DOMContentLoaded', function () {
  // const initialNonProductiveLinks = [
  //   "https://www.youtube.com/",
  //   "https://www.instagram.com/",
  //   "https://www.espn.com/"
  // ];

  loadWebsiteItems();

  // // Add initial links to "Non Productive" list
  // initialNonProductiveLinks.forEach(link => addItemToList(link, false));

  // Add event listener for "Add" button click
  document.getElementById('addBtnWebsite').addEventListener('click', addWebsite);

  document.getElementById('WebsiteInput').addEventListener('keypress', function (event) {
    if (event.key === 'Enter') {
      event.preventDefault(); // Prevent form submission
      addWebsite();
    }
  });

  // Attach event listeners dynamically for all existing and future delete buttons
  document.querySelectorAll('.delete-btn').forEach(function (button) {
    button.addEventListener('click', function () {
      const listItem = this.parentNode;
      const itemText = listItem.querySelector('span').textContent;

      listItem.remove(); // Remove the list item
      updateStoredList(itemText, false); // Mark the item as deleted in storage
    });
  });
});

function addWebsite() {
  const input = document.getElementById('WebsiteInput');
  let newItem = input.value.trim();

  // Specifically handle user input "youtube"
  if (newItem.toLowerCase() === 'youtube') {
    newItem = 'https://www.youtube.com/';
  } else {
    // Add "https://" and ".com" if not present and valid URL
    if (!newItem.startsWith('https://')) {
      newItem = `https://${newItem}`;
    }

    if (!newItem.includes('.') && !newItem.endsWith('/')) {
      newItem += '.com';
    }
  }

  storeWebsiteItems(newItem);
  input.value = ''; // Clear the input field
}

function addItemToList(itemText, isChecked) {
    const list = document.getElementById(isChecked ? 'Productive' : 'NotProductive');
    const listItem = document.createElement('li');
  
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = isChecked;
    checkbox.addEventListener('change', function () {
      updateStoredList(itemText, this.checked);
      listItem.remove();
      addItemToList(itemText, this.checked); // Dynamically re-render with updated state
    });
  
    const deleteBtn = document.createElement('button');
    deleteBtn.classList.add('delete-btn'); // Use class for styling
    deleteBtn.textContent = 'Delete';
  
    // Ensure the event listener is attached within the function:
    deleteBtn.addEventListener('click', function () {
      const listItem = this.parentNode; // Use 'this' for the clicked button
      const itemText = listItem.querySelector('span').textContent; // Get the text content
      listItem.remove(); // Remove the list item from the UI
      updateStoredList(itemText, false, true); // Mark the item as deleted in storage
    });
  
    const span = document.createElement('span');
    span.textContent = itemText;
  
    listItem.appendChild(checkbox);
    listItem.appendChild(span);
    listItem.appendChild(deleteBtn);
    list.appendChild(listItem);
  }

function storeWebsiteItems(newItem) {
  chrome.storage.sync.get({ WebsiteItems: [] }, function (data) {
    data.WebsiteItems.push({ text: newItem, checked: false });
    chrome.storage.sync.set({ WebsiteItems: data.WebsiteItems }, function () {
      addItemToList(newItem, false); // Add the item to the list after storing
    });
  });
}

function loadWebsiteItems() {
  chrome.storage.sync.get({ WebsiteItems: [] }, function (data) {
    data.WebsiteItems.forEach(function (item) {
      addItemToList(item.text, item.checked);
    });
  });
}

function updateStoredList(itemText, isChecked, isDeleted = false) {
  chrome.storage.sync.get({ WebsiteItems: [] }, function (data) {
    const index = data.WebsiteItems.findIndex(item => item.text === itemText);
    if (index !== -1) {
      if (isDeleted) {
        // Remove the item from the array if marked for deletion
        data.WebsiteItems.splice(index, 1);
      } else {
        // Update the checked status
        data.WebsiteItems[index].checked = isChecked;
      }
      // Save the updated array back to storage
      chrome.storage.sync.set({ WebsiteItems: data.WebsiteItems });
    }
  });
}
