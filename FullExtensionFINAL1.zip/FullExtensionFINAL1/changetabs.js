function navigateTabs(html_name) {
    // Query the current active tab in the current window
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        // tabs[0] will be the active tab in the current window
        var currentTab = tabs[0];
        if (currentTab) {
            // Update the URL of the current tab
            chrome.tabs.update(currentTab.id, {url: chrome.runtime.getURL(html_name)});
        }
    });
}

document.getElementById('aboutPage').addEventListener('click', function() {
    navigateTabs("aboutPage2.html");
});

document.getElementById('Dog_Home').addEventListener('click', function() {
    navigateTabs("homePage.html");
});

document.getElementById('To_Do_List').addEventListener('click', function() {
    navigateTabs("toDo.html");
});

document.getElementById('Classify_Websites').addEventListener('click', function() {
    navigateTabs("Classify2.html");
});

document.getElementById('Customize').addEventListener('click', function() {
    navigateTabs("customize.html");
});