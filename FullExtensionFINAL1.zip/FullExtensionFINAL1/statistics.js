function storeUserReportedData(website, timeSpent) {
  const existingData = localStorage.getItem('userReportedData');
  let data;

  if (existingData) {
    // Parse existing data from JSON format
    data = JSON.parse(existingData);
  } else {
    data = []; // Initialize an empty array
  }

  // Add new website and time spent to the data array
  data.push({ website, timeSpent });

  // Store the updated data in local storage, converting it back to JSON string
  localStorage.setItem('userReportedData', JSON.stringify(data));
}

function addToStatisticsList(website, timeSpent) {
  const list = document.getElementById('websiteTimes');

  // Check if the list element exists before creating and appending
  if (list) {
    const listItem = document.createElement('li');

    const websiteElement = document.createElement('span');
    websiteElement.textContent = website;

    const timeSpentElement = document.createElement('span');
    timeSpentElement.textContent = `(Time spent: ${timeSpent} minutes)`;

    listItem.appendChild(websiteElement);
    listItem.appendChild(timeSpentElement);
    list.appendChild(listItem);
  } else {
    console.error("The 'websiteTimes' element not found in the HTML.");
  }
}

document.getElementById('submitBtn').addEventListener('click', function () {
  const website = document.getElementById('websiteInput').value.trim();
  const timeSpent = parseInt(document.getElementById('timeInput').value);

  if (website && timeSpent >= 0) {
    // Validate and store user-reported data
    storeUserReportedData(website, timeSpent);

    // Add website and time to the statistics list
    addToStatisticsList(website, timeSpent);

    // Clear input fields for next submission (optional)
    document.getElementById('websiteInput').value = '';
    document.getElementById('timeInput').value = '';
  } else {
    alert('Please enter a valid website URL and time spent.');
  }
});
