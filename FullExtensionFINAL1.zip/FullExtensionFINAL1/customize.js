// Default Pinto
document.getElementById('defaultPinto').addEventListener('click', function() {
    replaceImageID('defaultPinto');
});

// Blue collar
document.getElementById('Blue_Collar').addEventListener('click', function() {
    replaceImageID('blueCollar');
});

// Load the initial image source from Chrome storage sync
chrome.storage.sync.get(['currentImageID'], function(result) {
    var initialImageID = result.currentImageID || 'defaultPinto';
    replaceImageID(initialImageID);
});

function replaceImageID(imgID) {

    if (imgID == 'defaultPinto') {
      imgSrc = 'pinto images/pinto.png'
    } else if (imgID == 'blueCollar') {
      imgSrc = 'pinto images/pintoCollar.png'
    } else {
      imgSrc = 'pinto images/pinto.png'
    }
    // Get the image element by ID
    var imgElement = document.getElementById('pinto');

    // Set the new image source
    imgElement.src = imgSrc;

    // Save the new image source to Chrome storage sync
    chrome.storage.sync.set({ 'currentImageID': imgID });

    // Optional: You can also update the alt attribute
    imgElement.alt = 'New Image Description';

    // Update the button text (assuming you want to change button text)
    document.getElementById('Blue_Collar').innerText = "Blue Collar";
}