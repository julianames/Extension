chrome.action.onClicked.addListener(function(tab) {
    chrome.tabs.update(tab.id, { url: chrome.runtime.getURL('homePage.html') });
});

// Initialize or update variables on startup
chrome.runtime.onInstalled.addListener(() => {
    initializeOrUpdateVariables();
    setupPeriodicUpdates();
  });
  
  chrome.runtime.onStartup.addListener(() => {
    initializeOrUpdateVariables();
    setupPeriodicUpdates();
  });
  
  function initializeOrUpdateVariables() {
    chrome.storage.sync.get(['happiness', 'poop', 'poop_tracking', 'lastUpdate'], data => {
      let { happiness = 30, poop = false, poop_tracking = 0, lastUpdate = Date.now() } = data;
      const currentTime = Date.now();
      const timePassed = currentTime - lastUpdate; // in milliseconds
      const periodsPassed = Math.floor(timePassed / (30 * 60 * 1000)); // 30 minutes in milliseconds
  
      // Update happiness for the time passed
      happiness -= periodsPassed;
      // Clamp happiness within the range of -30 to 90
      happiness = Math.max(-30, Math.min(90, happiness));
  
      // Determine the state based on updated values
      let state = determineState(happiness, poop);
  
      // Save updated values
      chrome.storage.sync.set({ happiness, poop, poop_tracking, lastUpdate: currentTime, state });
    });
  }
  
  function setupPeriodicUpdates() {
    // Setup an alarm to trigger every 30 minutes
    chrome.alarms.create("updateVariables", { periodInMinutes: 30});
  
    chrome.alarms.onAlarm.addListener((alarm) => {
      if (alarm.name === "updateVariables") {
        updateVariables();
      }
    });
  }
  
  function updateVariables() {
    chrome.storage.sync.get(['happiness', 'poop', 'poop_tracking'], data => {
      let { happiness, poop, poop_tracking } = data;
  
      // Decrease happiness by 1
      happiness -= 1;
      // Clamp happiness within the range of -30 to 90
      happiness = Math.max(-30, Math.min(90, happiness));
  
      // Increment poop_tracking by 5
      if (poop == false) {
        poop_tracking += 5;
      }
  
      // Random chance to reset poop_tracking and change poop to true
      if (Math.random() < (poop_tracking / 100)) {
        poop_tracking = 0;
        poop = true; 
      }
  
      // Determine the state based on updated values
      let state = determineState(happiness, poop);
      //document.getElementById("State").innerText("State: " + state + " happiness: " + happiness + " poop: " + poop + " poop_tracking: " + poop_tracking);
      // Save updated values
      chrome.storage.sync.set({ happiness, poop, poop_tracking, lastUpdate: Date.now(), state }, () => {
        chrome.runtime.sendMessage({ action: "updateState", state });
      });
    });
  }

  //Website Tracker Function
  chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.timeSpent) {
      const url = new URL(request.url);
      const hostname = url.hostname;
      console.log('Hostname: '+hostname)
      const parts = hostname.split('.');
      const siteName = parts.length > 2 ? parts[parts.length - 2] : parts[0];
      
      // Fetch the list of checked and non-checked sites
      chrome.storage.sync.get(['happiness'], function(result) {
        let happiness = result.happiness ? result.happiness : 0; // Initialize happiness if not present
        
        // Use Promise.all to wait for both calls to complete
        Promise.all([
          getWebsiteItemsText(true),
          getWebsiteItemsText(false)
        ]).then(([checkedTexts, nonCheckedTexts]) => {
          // Combine the results from both calls
          const siteNameFound_productive = checkedTexts.some(text => text.includes(siteName));
          const siteNameFound_nonproductive = nonCheckedTexts.some(text => text.includes(siteName));
          
          // Check if siteName exists in any of the texts
          if (siteNameFound_productive) {
            // Site name found, do something here
            console.log(`Site name found in Productive category: ${siteName}`);
            happiness += Math.floor(request.timeSpent / 60000);
          } else  if (siteNameFound_nonproductive) {
            console.log(`Site name found in Nonproductive category: ${siteName}`);
            happiness -= Math.floor(request.timeSpent / 60000 * 4);
          } else {
            console.log(`Site name not found in user's site list ${siteName}`);
          }
          chrome.storage.sync.set({'happiness': happiness}, function() {
            console.log(`Hostname: ${hostname}, Current happiness: ${happiness}`);
          });
        });
      });
    }
  });

  function getWebsiteItemsText(isChecked) {
    return new Promise((resolve, reject) => {
      chrome.storage.sync.get({ WebsiteItems: [] }, function (data) {
        const filteredTexts = data.WebsiteItems
                                  .filter(item => item.checked === isChecked)
                                  .map(item => item.text);
        resolve(filteredTexts); // Resolve the promise with the filtered texts
      });
    });
  }
  

  function determineState(happiness, poop) {
    if (happiness <= 0) {
      return 'sad';
    } else if (poop) {
      return 'poop';
    } else if (happiness > 0 && happiness <= 60) {
      return 'content';
    } else if (happiness > 60) {
      return 'happy';
    }
  }